Privacy Policy
This browser extention does not collect or share any user data